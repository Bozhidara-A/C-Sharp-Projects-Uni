﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace upr2._2
{
    class Program
    {
        struct Contact
        {
            public string name { get; set; }
           public string id { get; set; }
           public string number { get; set; }

            public Contact(string name, string id, string number)
            {
                this.name = name;
                this.id = id;
                this.number = number;
            }
            public override string ToString()
            {
                return string.Format("{0}{1}{2}", name, id, number);
            }

        }
        static void Main(string[] args)
        {
            string text = System.IO.File.ReadAllText(@"C:\Users\Bozhidara\Desktop\Lab2\input-02.txt");
           
            Console.WriteLine("hello");

            string namesRegex = @"[[А-я]+]";
            string numberRegex = @"\+395 [0-9]{3} [0-9]{2} [0-9]{2}";
            string idRegex = @"(0-9){4,}";
            var namesMatches = new Regex(namesRegex).Matches(text);
            var numberMatches = new Regex(numberRegex).Matches(text);
            var idMatches = new Regex(idRegex).Matches(text);

            List<Contact> contactList = new List<Contact>();

            for(int i=0; i<namesMatches.Count; i++)
            {
                contactList.Add(new Contact(namesMatches[i].Value, numberMatches[i].Value, idMatches[i].Value));

            }
            for (int i = 0; i < contactList.Count; i++)
            {
                Console.WriteLine(contactList[i]);
            }

        }
    }
}
