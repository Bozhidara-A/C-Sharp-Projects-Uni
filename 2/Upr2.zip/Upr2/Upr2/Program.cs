﻿using System;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;


namespace Upr2
{
    class Program
    {
        public struct Coords
        {
            public float lat { get; set; } 
            public float lng { get; set; }
            public Coords(float lat, float lng)
            {
                this.lat = lat;
                this.lng = lng;
            }
            public override string ToString()
            {
                return string.Format("{0}{0}", lat, lng);
            }
        }
      
        static async System.Threading.Tasks.Task Main(string[] args)
        {
            
            string text = System.IO.File.ReadAllText(@"C:\Users\Bozhidara\Desktop\Lab2\input-01.txt");
            string[] splitArr = text.Split(";");
            List<Coords> coordsList = new List<Coords>();
            for (int i = 0; i < splitArr.Length; i++)
            {
                string[] points = splitArr[i].Split(",");
                Console.WriteLine(points[0]);
                Console.WriteLine(points[1]);
                coordsList.Add(new Coords(float.Parse(points[0], System.Globalization.CultureInfo.InvariantCulture), float.Parse(points[1], System.Globalization.CultureInfo.InvariantCulture)));
            }
           
            var json = JsonSerializer.Serialize(coordsList);
            await File.WriteAllTextAsync("C:\\Users\\Bozhidara\\Desktop\\Lab2\\json.json",json);

        }
    }
}
