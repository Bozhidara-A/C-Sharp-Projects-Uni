﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace upr3._1
{
    class Program
    {
        struct News
        {
            public string title { get; set; }
            public string time { get; set; }
            public string author { get; set; }
            public News( string title, string time, string author)
            {
                this.title = title;
                this.time = time;
                this.author = author;
            }
        }
        static async Task Main(string[] args)
        {
            //await getCountry();
            //await getTime();
            await getNews();
        }
        static async Task getCountry()
        {
            HttpClient client = new HttpClient();
            var result = await client.GetStringAsync(" https://progress.razorlabs.com/ip-detect/?ip=195.24.90.1");
            Console.WriteLine(result);
        }
        static async Task getTime()
        {
            Console.OutputEncoding = Encoding.UTF8;
            HttpClient client = new HttpClient();
            string address = await client.GetStringAsync("https://www.timeanddate.com/worldclock/bulgaria/sofia");
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(address);
            var element = htmlDoc.GetElementbyId("ct");
            Console.WriteLine(element.InnerText);
          
        }
        static async Task getNews()
        {
            List<News> newsList = new List<News>();
            Console.OutputEncoding = Encoding.UTF8;
            HttpClient client = new HttpClient();
            string address = await client.GetStringAsync("https://www.mediapool.bg/");
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(address);
            HtmlNodeCollection htmlNodes = htmlDoc.DocumentNode.SelectNodes("//article");
            foreach(HtmlNode node in htmlNodes)
            {
                string title = node.SelectSingleNode(".//a[@itemprop='url']").InnerText.Trim();
                if (!(title.Contains("Covid-19") || title.Contains("Коронавирус") || title.Contains("пандемия")))
                {
                    Console.WriteLine(title);
                    string time = node.SelectSingleNode(".//time").InnerText.Trim();
                    Console.WriteLine(time);
                    var author = node.SelectSingleNode(".//a[@itemprop='author']");
                    string authorName = " ";
                    if (author != null)
                    {
                        authorName = node.SelectSingleNode(".//a[@itemprop='author']").InnerText.Trim();
                    }
                    Console.WriteLine(authorName);
                    Console.WriteLine("\n");
                }
                  //newsList.Add(new News(title, time, "1"));
            }
            /*for (int i = 0; i < newsList.Count; i++)
            {
                Console.WriteLine(newsList[i]);
                     }*/
        }
    }
}
