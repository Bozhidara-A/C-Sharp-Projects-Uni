﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1_upr1
{
    interface IElipse
    {
        public bool isElipse();

    }
}
