﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1_upr1
{
    class Circle : Shape, IElipse
    {
        public bool isElipse()
        {
            throw new NotImplementedException();
        }
        public override double GetPer()
        {
            throw new NotImplementedException();

        }
        public override double GetLitse()
        {
            throw new NotImplementedException();
        }

    }
}
