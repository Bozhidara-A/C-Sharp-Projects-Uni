﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1_upr1
{
    class Triangle <T> : Shape
    {
        T a;
        T b;
        T c;
        private Triangle( T a, T b, T c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        public override string ToString()
        {
            return $"{this.a}, {this.b}, {this.c}";
        }
        public static bool getInstance(ref Triangle<T> triangle, T a, T b, T c)
        {
            if (typeof(T) == typeof(int) || typeof(T) == typeof(float))
            {
                double A = Convert.ToDouble(a);
                double B = Convert.ToDouble(b);
                double C = Convert.ToDouble(c);
                if (A + B > C && A + C > B && B + C > A)
                {
                    triangle = new Triangle<T>(a, b, c);
                    return true;
                }
                else
                {
                    triangle = null;
                    return false;
                }
            }
            else
            {
                Console.WriteLine("Triangle values must be int or float type.");
                return false;
            }
        }

        public override double GetLitse()
        {
            double A = Convert.ToDouble(a);
            double B = Convert.ToDouble(b);
            double C = Convert.ToDouble(c);
            double p = (A + B + C) / 2;
            double S = Math.Sqrt(p * (p - A) * (p - B) * (p - C));
            return S;
        }

        public override double GetPer()
        {
            double A = Convert.ToDouble(a);
            double B = Convert.ToDouble(b);
            double C = Convert.ToDouble(c);
            double P = A + B + C;
            return P;
        }
    }
}
