﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1_upr1
{
    abstract class Shape
    {
        public abstract double GetPer();
        public abstract double GetLitse();

      
        private int color;

        public Colors Color
        {
            get
            {
                switch (color)
                {
                    case 1:
                        return Colors.BLUE;
                    case 2:
                        return Colors.RED;
                    case 3:
                        return Colors.GREEN;
                    default: throw new Exception("Not valid color code.");
                }
            }
            set
            {
                switch (value)
                {
                    case Colors.BLUE:
                        color = 1;
                        break;
                    case Colors.RED:
                        color = 2;
                        break;
                    case Colors.GREEN:
                        color = 3;
                        break;
                }
            }
        }

     

        public enum Colors
        {
            BLUE = 1,
            RED = 2,
            GREEN = 3
        }
    }
}
