﻿using System;

namespace ConsoleApp1_upr1
{
    class Program
    {
        static void Main(string[] args)
        {
            Triangle<int> t = null;
            Triangle<int>.getInstance(ref t, 4, 4, 4);
            Console.WriteLine(t);
            Console.WriteLine(t.GetPer());
            Console.WriteLine(t.GetLitse());
            Triangle<double> r = null;
            Triangle<double>.getInstance(ref r, 4, 4, 4);
            Console.WriteLine(r);
            Console.WriteLine(r.GetPer());
            Console.WriteLine(r.GetLitse());

        }
    }
}
