﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1_upr1
{
    class Square : Rectangle
    {
        public override double GetPer()
        {
            return base.GetPer();
        }

        public override double GetLitse()
        {
            return base.GetLitse();
        }

        public static double GetSquareLitse(double a)
        {
            double S = a * a;
            return S;
        }
    }
}
